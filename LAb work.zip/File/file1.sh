#!/bin/bash
echo "ENter a numnber"
read n
if [$n -eq 0 ]
then 
echo "The entered number is zero" 
elif [$n -lt 0]
then 
echo "the number is negative"
else 
echo "The number is positive"
fi
