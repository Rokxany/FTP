#!/bin/bash
echo "1. addtion "
echo "2. Substraction"
echo "3. Division "

echo "Enter option: "
read option

echo "Enter First num: "
read n1

echo "Enter the second num"
read n2
case $option in 
1) echo "sum =" $((n1 + n2));;
2) echo "sum =" $((n1 - n2));;
3) echo "sum =" $((n1 / n2));;
*) echo "Error agya boss" ;;
esac
