#!/bin/bash
echo "Press 1 for addtion"
echo "Press 2 for Minus"
echo "Press 3 for Multiplication"
echo "Press 4 to leave"
echo
echo "Enter Option Number"
read option

echo "Enter Number"
read a

echo "Enter Number"
read b

case $option in
    1) echo "sum = $(( a + b ))" ;;
    2) echo "sum = $(( a - b ))" ;;
    3) echo "sum = $(( a * b ))" ;;
    *) echo "Error" ;;
esac

