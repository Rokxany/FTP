#!/bin/bash

count=10
word=acm
echo $count 
echo $word
if [ $count -eq 100 ]
then
	echo "condition is true"
else
	echo "Number is not equal to zero"
fi

if [ $word == "acsm" ];
then
	echo "condition is really true"
else
	echo "Condition is really false"
fi

echo
echo "This is a Odd/Even checker"
echo "Enter a number: "
read num
rem=$(($num%2))
if [ $rem -eq 0 ];
then
	echo "$num is even Number"
else
	echo "$num is odd number"
fi

echo
echo "Enter an another number"
read n
if [ $n -eq 0 ]
then
	echo "Number is zero"
elif [ $n -lt 0 ]
then
	echo "Number is Negative"
else
	echo "Number is positive"
fi

